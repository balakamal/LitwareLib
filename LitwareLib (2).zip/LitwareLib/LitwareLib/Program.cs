﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LitwareLib
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Employee employee = new Employee();
                Console.Write("Enter Employee ID: ");
                int EmpId = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Employee ID: ");
                string EmpName = Console.ReadLine();
                Console.Write("Enter Employee ID: ");
                double Salary = Convert.ToDouble(Console.ReadLine());
                employee.SetEmpNo(EmpId);
                employee.SetEmpName(EmpName);
                employee.SetSalary(Salary);
                Console.WriteLine(employee.CalculateSalary());

            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
