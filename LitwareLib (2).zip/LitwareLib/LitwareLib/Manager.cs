﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LitwareLib
{
    class Manager:Employee, IPrintable
    {
        private double PetrolAllowance;
        private double FoodAllowance;
        private double OtherAllowances;

        public override double CalculateSalary()
        {
            PetrolAllowance = (Salary * 8) / 100;
            FoodAllowance = (Salary * 13) / 100;
            OtherAllowances = (Salary * 3) / 100;
            PF = (GrossSalary * 10) / 100;
            GrossSalary += PetrolAllowance + FoodAllowance + OtherAllowances;
            TDS = (GrossSalary * 18) / 100;
            NetSalary = GrossSalary - (PF + TDS);
            return NetSalary;
        }
    }
}
