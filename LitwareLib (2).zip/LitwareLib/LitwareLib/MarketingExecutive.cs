﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LitwareLib
{
    class MarketingExecutive : Employee
    {
        private double KilometerTravel;
        private double TourAllowances;

        private int TelephoneAllowances = 1000;

        public void SetKilometersTravel(double Kilo)
        {
            KilometerTravel = Kilo;
            TourAllowances = KilometerTravel * 5;
        }

        public override double CalculateSalary()
        {
            
            PF = (GrossSalary * 10) / 100;
            TDS = (GrossSalary * 18) / 100;
            NetSalary = GrossSalary - (PF + TDS);
            GrossSalary += TourAllowances + TelephoneAllowances;
            return NetSalary;
        }
    }
}
